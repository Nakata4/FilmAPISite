package Films;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

public class OnlineFilms {
	public static void Online(){

		System.out.println("Online watching platform");

		}

		public static int return50(){

		return 50;

		}

		public static int timesTwo(int i){

		return (i * 2);

		}
		public class PlayingNow {

		    private static final String template = "Hello, Username!";
		    private final FilmTime counter = new FilmTime();
		    public PlayingNow(Object incrementAndGet, String format) {
				// TODO Auto-generated constructor stub
			}
			@RequestMapping("/greeting")
		    public PlayingNow playingnow(@RequestParam(value="name", defaultValue="film") String name) {
		        return new PlayingNow(( counter).incrementAndGet(),
		                            String.format(template, name));
		    }
		}
}
