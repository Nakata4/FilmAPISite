package Films;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public  class FilmSalesSystem extends JFrame implements ActionListener, ComponentListener
{
	private static final long serialVersionUID = 1L;
	public static final int CARS_COUNT = 0;
	public static final int MANUFACTURERS_COUNT = 1;
	public static final int AVERAGE_PRICE = 2;
	public static final int AVERAGE_DISTANCE = 3;
	public static final int AVERAGE_AGE = 4;
	public static final int NAME_COUNT = 5;
	private static final boolean FilmUpdate = false;
	private static final int FILMS_COUNT = 0;
	

	private String file;
	private Dialog aboutDlg;
	private boolean filmUpdate = false;
	private JPanel topPanel = new JPanel(new BorderLayout());
	private JPanel titlePanel = new JPanel(new GridLayout(2, 1));
	private JLabel pictureLabel = new JLabel();
	private JLabel filmLabel = new JLabel("Watch Online", JLabel.CENTER);
	private JLabel salesSystemLabel = new JLabel("Brought To You By Atanas Cholv", JLabel.CENTER);
	private JTabbedPane theTab = new JTabbedPane(JTabbedPane.TOP);
	private JMenuBar menuBar = new JMenuBar();
	private JMenu fileMenu = new JMenu("About");
	private JMenuItem aboutItem = new JMenuItem("About");
	private JMenuItem exitItem = new JMenuItem("Exit");
	
	

	public void aboutMenuItemClicked()
	{
		
		if (aboutDlg == null)
			aboutDlg = new Dialog(this, "About", true);
		aboutDlg.showAbout();
	}

	public void actionPerformed(ActionEvent ev)
	{
		if (ev.getSource() == aboutItem)
			aboutMenuItemClicked();
		else if (ev.getSource() == exitItem)
			closing();
	}

	
	public void addFilmUpdateListener(Object listener)
	{
		Container registeredListeners = null;
		if (!(listener == null))
			registeredListeners.add((Component) listener);
	}


	public void closing()
	{
		boolean ok;

		if (filmUpdate)
		{
			do
			{
				
				
				{
					int result = JOptionPane.showConfirmDialog(this, "The data file could "
							+ "not be written, possibly because you don't have access to "
							+ "this location.\nIf you chose No to retry you will lose all "
							+ "film data from this session.\n\nWould you like to reattempt "
							+ "saving the data file?", "Problem "
									+ "saving data", JOptionPane.YES_NO_OPTION);

					if (result == JOptionPane.YES_OPTION)
						ok = false;
					else
						ok = true;
				}
			}
			while (!ok);
		}

		System.exit(0);
	}

	public void componentHidden(ComponentEvent ev) {}

	public void componentMoved(ComponentEvent ev) {}

	
	public void componentResized(ComponentEvent ev)
	{
		if (this == ev.getComponent())
		{
			Dimension size = getSize();

			if (size.height < 530)
				size.height = 530;
			if (size.width < 675)
				size.width = 675;

			setSize(size);
		}
	}

	public void componentShown(ComponentEvent ev) {}

	
	public static double[] convertToRange(String s)
	{
		String[] parts = s.trim().split("-");
		double[] bounds = new double[2];

		try
		{
			if (parts.length == 1)
			{
				String c = s.substring(s.length() - 1);

				
				if (c.equals("+"))
				{
					
					bounds[0] = Double.parseDouble(s.substring(0, s.length() - 1));
					
					bounds[1] = -1;
				}
				else
				{
					
					bounds[0] = Double.parseDouble(s);
					bounds[1] = bounds[0];
				}
			}
			
			else if(parts.length == 2)
			{
				bounds[0] = Double.parseDouble(parts[0]);
				bounds[1] = Double.parseDouble(parts[1]);
				if (bounds[0] > bounds[1])
				{
					
					bounds[0] = -1;
					bounds[1] = -1;
				}
			}
		}
		catch (NumberFormatException exp)
		{
			
			bounds[0] = -1;
			bounds[1] = -1;
		}

		return bounds;
	}

	
	
	public boolean getFilmUpdate()
	{
		return FilmUpdate;
	}

	
	public double getStatistics(int type)
	{
		double result = 0;

		if (type == FILMS_COUNT)
		

		return result;
		return result;
	}


public static void main(String[] args)
{
	FilmSalesSystem FilmSales = new FilmSalesSystem();
}
}
		
	

