package Films;
public class FilmUpdate extends java.util.EventObject
{

	public FilmUpdate(Object source)
	{
		super(source);
	}
}